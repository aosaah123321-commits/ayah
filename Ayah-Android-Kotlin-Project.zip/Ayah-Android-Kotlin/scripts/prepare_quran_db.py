#!/usr/bin/env python3
"""
Pre-population helper for Ayah (آية) Android App.
Validates and builds app/src/main/assets/quran_uthmani_muyassar.json from verified
Uthmani script (KFGQPC / Tanzil) and Al-Tafsir Al-Muyassar sources without altering
any Tashkeel, Waqf marks, or Quranic orthography.

Usage:
  python3 scripts/prepare_quran_db.py \
    --quran path/to/quran-uthmani.json \
    --tafsir path/to/ar.muyassar.json \
    --out app/src/main/assets/quran_uthmani_muyassar.json
"""

import argparse
import json
import re
from pathlib import Path

TASHKEEL_RE = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]")


def normalize_arabic_for_fts(text: str) -> str:
    cleaned = TASHKEEL_RE.sub("", text)
    cleaned = re.sub(r"[آأإٱ]", "ا", cleaned)
    cleaned = cleaned.replace("ى", "ي").replace("ة", "ه")
    cleaned = cleaned.replace("ؤ", "و").replace("ئ", "ي")
    return re.sub(r"\s+", " ", cleaned).strip()


def validate_and_build(quran_path: Path, tafsir_path: Path, out_path: Path) -> None:
    quran_data = json.loads(quran_path.read_text(encoding="utf-8"))
    tafsir_data = json.loads(tafsir_path.read_text(encoding="utf-8"))

    surahs = quran_data["surahs"]
    tafsir_map = {
        (item["surah"], item["ayah"]): item["text"]
        for item in tafsir_data["ayahs"]
    }

    assert len(surahs) == 114, f"Expected 114 surahs, found {len(surahs)}"

    out_surahs = []
    out_ayahs = []
    ayah_global_id = 1

    for surah in surahs:
        s_num = int(surah["number"])
        ayah_list = surah["ayahs"]
        out_surahs.append({
            "number": s_num,
            "name": surah["name"],
            "revelationType": surah["revelationType"],
            "ayahCount": len(ayah_list),
        })
        for ayah in ayah_list:
            a_num = int(ayah["numberInSurah"])
            uthmani_exact = ayah["text"]
            assert len(uthmani_exact) > 0, f"Empty ayah at {s_num}:{a_num}"
            tafsir_text = tafsir_map.get((s_num, a_num), "")
            out_ayahs.append({
                "id": ayah_global_id,
                "surahNumber": s_num,
                "surahName": surah["name"],
                "ayahNumber": a_num,
                "uthmaniText": uthmani_exact,
                "normalizedText": normalize_arabic_for_fts(uthmani_exact),
                "tafsirMuyassar": tafsir_text,
                "juz": int(ayah.get("juz", 1)),
                "page": int(ayah.get("page", 1)),
            })
            ayah_global_id += 1

    assert len(out_ayahs) == 6236, f"Expected 6236 ayahs, found {len(out_ayahs)}"

    payload = {
        "schemaVersion": 1,
        "scriptStandard": "KFGQPC_UTHMANI_HAFS",
        "tafsirSource": "Al-Tafsir Al-Muyassar",
        "totalSurahs": len(out_surahs),
        "totalAyahs": len(out_ayahs),
        "surahs": out_surahs,
        "ayahs": out_ayahs,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Generated {out_path} ({len(out_surahs)} surahs, {len(out_ayahs)} ayahs)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--quran", type=Path, required=True)
    parser.add_argument("--tafsir", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("app/src/main/assets/quran_uthmani_muyassar.json"))
    args = parser.parse_args()
    validate_and_build(args.quran, args.tafsir, args.out)
