#!/usr/bin/env bash
set -euo pipefail

# Build installable APK for Ayah (آية) — Developer: وايل الوايلي
# Requires JDK 17+, Android SDK (API 35), and Gradle 8.9+ (or Android Studio).

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$PROJECT_DIR"

if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug --no-daemon
else
  echo "Error: gradle is not installed on PATH. Open this folder in Android Studio and select Build > Build APK(s)." >&2
  exit 1
fi

APK_SRC="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
APK_OUT="$PROJECT_DIR/Ayah-app-debug.apk"

if [ -f "$APK_SRC" ]; then
  cp "$APK_SRC" "$APK_OUT"
  echo "APK generated successfully: $APK_OUT"
else
  echo "Build finished, but APK was not found at $APK_SRC" >&2
  exit 1
fi
