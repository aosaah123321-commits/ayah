# Keep Room entities & Kotlinx Serialization models for release R8 minification
-keep class com.ayah.app.data.local.entity.** { *; }
-keep class com.ayah.app.data.local.PrepopulatedQuranPayload { *; }
-keep class com.ayah.app.data.local.PrepopulatedSurah { *; }
-keep class com.ayah.app.data.local.PrepopulatedAyah { *; }
-keep class com.ayah.app.data.local.PrepopulatedAdhkar { *; }
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
