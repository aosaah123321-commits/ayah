package com.ayah.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val EmeraldColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = EmeraldPrimary,
    secondary = ChampagneGoldBright,
    onSecondary = EmeraldPrimary,
    background = EmeraldPrimary,
    onBackground = IvoryWhite,
    surface = EmeraldSurface,
    onSurface = IvoryWhite,
    surfaceVariant = EmeraldElevated,
    onSurfaceVariant = IvoryMuted,
    outline = HairlineBorder
)

private val AmoledColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = AmoledBlack,
    secondary = ChampagneGoldBright,
    onSecondary = AmoledBlack,
    background = AmoledBlack,
    onBackground = IvoryWhite,
    surface = AmoledSurface,
    onSurface = IvoryWhite,
    surfaceVariant = AmoledSurface,
    onSurfaceVariant = IvoryMuted,
    outline = HairlineBorder
)

@Composable
fun AyahTheme(
    amoledMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (amoledMode) AmoledColorScheme else EmeraldColorScheme

    // Strict RTL enforcement across the entire application
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AyahTypography,
            content = content
        )
    }
}
