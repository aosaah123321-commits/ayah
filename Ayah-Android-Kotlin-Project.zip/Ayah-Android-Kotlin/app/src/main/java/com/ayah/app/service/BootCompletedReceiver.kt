package com.ayah.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ayah.app.AyahApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val pendingResult = goAsync()
            val app = context.applicationContext as AyahApplication
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val settings = app.preferences.settingsFlow.first()
                    if (settings.isLockScreenEnabled) {
                        ScreenMonitorService.start(context)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
