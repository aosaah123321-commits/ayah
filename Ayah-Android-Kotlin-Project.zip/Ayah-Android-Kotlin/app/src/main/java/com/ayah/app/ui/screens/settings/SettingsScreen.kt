package com.ayah.app.ui.screens.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayah.app.R
import com.ayah.app.data.preferences.AyahSettings
import com.ayah.app.data.preferences.BackgroundPreset
import com.ayah.app.data.preferences.DisplayMode
import com.ayah.app.data.preferences.TextColorTheme
import com.ayah.app.data.preferences.TriggerMode
import com.ayah.app.ui.MainViewModel
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.util.HijriDateFormatter

@Composable
fun SettingsScreen(
    settings: AyahSettings,
    viewModel: MainViewModel,
    onOpenPermissions: () -> Unit
) {
    val context = LocalContext.current
    val galleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.saveCustomGalleryBackground(context, uri)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldPrimary)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "التحكم والإعدادات",
            color = ChampagneGold,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        // Trigger Mode
        SettingsSectionCard("وضع التحديث على شاشة القفل") {
            TriggerMode.entries.forEach { mode ->
                val label = when (mode) {
                    TriggerMode.EVERY_WAKE -> "عند كل إضاءة للشاشة"
                    TriggerMode.EVERY_UNLOCK -> "عند كل فتح للقفل"
                    TriggerMode.INTERVAL -> "بفاصل زمني محدد"
                }
                SelectableOptionRow(
                    label = label,
                    selected = settings.triggerMode == mode,
                    onClick = { viewModel.setTriggerMode(mode) }
                )
            }
            if (settings.triggerMode == TriggerMode.INTERVAL) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15 to "١٥ د", 60 to "١ س", 360 to "٦ س", 1440 to "٢٤ س").forEach { (mins, text) ->
                        val active = settings.intervalMinutes == mins
                        Surface(
                            color = if (active) ChampagneGold else EmeraldPrimary,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.setIntervalMinutes(mins) }
                        ) {
                            Text(
                                text = text,
                                color = if (active) EmeraldPrimary else IvoryWhite,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp)
                            )
                        }
                    }
                }
            }
        }

        // Display Mode & No-Repeat Cycle
        SettingsSectionCard("أسلوب العرض ومنع التكرار") {
            DisplayMode.entries.forEach { mode ->
                val label = when (mode) {
                    DisplayMode.SINGLE_AYAH -> "آية واحدة"
                    DisplayMode.SHORT_PASSAGE -> "مقطع قصير (٢–٣ آيات متصلة)"
                }
                SelectableOptionRow(
                    label = label,
                    selected = settings.displayMode == mode,
                    onClick = { viewModel.setDisplayMode(mode) }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            SettingsSwitchRow(
                title = "منع التكرار (ختمة كاملة ٦,٢٣٦ آية)",
                checked = settings.noRepeatEnabled,
                onCheckedChange = viewModel::setNoRepeatEnabled
            )
            OutlinedButton(
                onClick = viewModel::resetNoRepeatCycle,
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
            ) {
                Text("إعادة ضبط دورة الآيات")
            }
        }

        // Quiet Hours & Salawat Reminder
        SettingsSectionCard("أوقات عدم الإزعاج والأذكار") {
            SettingsSwitchRow(
                title = "تفعيل أوقات عدم الإزعاج (١١:٠٠ م – ٥:٣٠ ص)",
                checked = settings.quietHoursEnabled,
                onCheckedChange = viewModel::setQuietHoursEnabled
            )
            SettingsSwitchRow(
                title = "تذكير الصلاة على النبي محمد وآله",
                checked = settings.salawatReminderEnabled,
                onCheckedChange = viewModel::setSalawatReminderEnabled
            )
            SettingsSwitchRow(
                title = "نغمة لطيفة عند فتح التطبيق (معطلة افتراضياً)",
                checked = settings.ambientChimeEnabled,
                onCheckedChange = viewModel::setAmbientChimeEnabled
            )
        }

        // Typography & Backgrounds
        SettingsSectionCard("الخط والمظهر والخلفيات") {
            Text(
                text = "حجم الخط العثماني: ${HijriDateFormatter.toArabicDigits(settings.fontSizeSp.toInt())}",
                color = IvoryWhite,
                fontSize = 14.sp
            )
            Slider(
                value = settings.fontSizeSp,
                onValueChange = viewModel::setFontSizeSp,
                valueRange = 20f..38f,
                colors = SliderDefaults.colors(thumbColor = ChampagneGold, activeTrackColor = ChampagneGold)
            )

            Text(text = "لون النص", color = IvoryMuted, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    TextColorTheme.IVORY to "عاجي",
                    TextColorTheme.GOLD to "ذهبي",
                    TextColorTheme.EMERALD to "زمردي"
                ).forEach { (theme, label) ->
                    val active = settings.textColorTheme == theme
                    Surface(
                        color = if (active) ChampagneGold else EmeraldPrimary,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.setTextColorTheme(theme) }
                    ) {
                        Text(
                            text = label,
                            color = if (active) EmeraldPrimary else IvoryWhite,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            SettingsSwitchRow(
                title = "الوضع الليلي الكامل AMOLED (#000000)",
                checked = settings.amoledMode,
                onCheckedChange = viewModel::setAmoledMode
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "خلفية شاشة القفل (دون إنترنت)", color = IvoryMuted, fontSize = 13.sp)
            listOf(
                BackgroundPreset.EMERALD_ARABESQUE to "زخرفة زمردية هادئة",
                BackgroundPreset.NIGHT_SKY to "سماء ليل وصحراء",
                BackgroundPreset.MOUNTAINS to "جبال عند الشفق",
                BackgroundPreset.AMOLED_BLACK to "أسود حالك AMOLED"
            ).forEach { (preset, label) ->
                SelectableOptionRow(
                    label = label,
                    selected = settings.backgroundPreset == preset,
                    onClick = { viewModel.setBackgroundPreset(preset) }
                )
            }
            OutlinedButton(
                onClick = { galleryPicker.launch("image/*") },
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
            ) {
                Text("اختيار صورة من المعرض وحفظها محلياً")
            }
        }

        // Permissions & Developer Card
        OutlinedButton(
            onClick = onOpenPermissions,
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
        ) {
            Text("مراجعة صلاحيات شاشة القفل وإعدادات البطارية")
        }

        Surface(
            color = EmeraldSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.25f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "عن التطبيق والمطور",
                    color = ChampagneGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.developer_attribution),
                    color = IvoryWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "تطبيق آية يعمل ١٠٠٪ دون إنترنت ودون أي أذونات شبكة.",
                    color = IvoryMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(title: String, content: @Composable () -> Unit) {
    Surface(
        color = EmeraldSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.22f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = title, color = ChampagneGold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            content()
        }
    }
}

@Composable
private fun SelectableOptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) ChampagneGold.copy(alpha = 0.16f) else EmeraldPrimary.copy(alpha = 0.6f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (selected) ChampagneGold else ChampagneGold.copy(alpha = 0.15f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Text(
            text = label,
            color = if (selected) ChampagneGold else IvoryWhite,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun SettingsSwitchRow(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, color = IvoryWhite, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary, checkedTrackColor = ChampagneGold)
        )
    }
}
