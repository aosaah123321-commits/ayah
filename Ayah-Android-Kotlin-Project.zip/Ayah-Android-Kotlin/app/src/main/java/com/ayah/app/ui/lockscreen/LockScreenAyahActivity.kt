package com.ayah.app.ui.lockscreen

import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayah.app.AyahApplication
import com.ayah.app.R
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.preferences.AyahSettings
import com.ayah.app.data.preferences.BackgroundPreset
import com.ayah.app.data.preferences.TextColorTheme
import com.ayah.app.ui.components.IslamicPatternCanvas
import com.ayah.app.ui.theme.AmoledBlack
import com.ayah.app.ui.theme.AyahTheme
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.ui.theme.UthmaniFontFamily
import com.ayah.app.util.HijriDateFormatter
import kotlinx.coroutines.launch
import java.io.File

class LockScreenAyahActivity : ComponentActivity() {

    private var currentAyahIdExtra: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureLockScreenWindow()

        currentAyahIdExtra = intent?.getIntExtra(EXTRA_PRIMARY_AYAH_ID, -1) ?: -1
        val app = application as AyahApplication

        setContent {
            val settings by app.preferences.settingsFlow.collectAsState(initial = AyahSettings())
            var passage by remember { mutableStateOf<List<AyahEntity>>(emptyList()) }
            val scope = rememberCoroutineScope()

            androidx.compose.runtime.LaunchedEffect(currentAyahIdExtra, settings.activeAyahId, settings.displayMode) {
                val targetId = if (currentAyahIdExtra > 0) currentAyahIdExtra else settings.activeAyahId
                val primary = app.repository.getAyahOrFallback(targetId)
                if (primary != null) {
                    passage = app.repository.getPassageForSettings(primary, settings.displayMode)
                }
            }

            val primaryAyah = passage.firstOrNull()
            val isFavorite by (if (primaryAyah != null) {
                app.repository.observeIsFavorite(primaryAyah.id)
            } else {
                kotlinx.coroutines.flow.flowOf(false)
            }).collectAsState(initial = false)

            AyahTheme(amoledMode = settings.amoledMode) {
                LockScreenOverlayContent(
                    passage = passage,
                    settings = settings,
                    isFavorite = isFavorite,
                    onNextAyah = {
                        primaryAyah?.let { current ->
                            scope.launch {
                                val next = app.repository.stepSequentialAyah(current.id, forward = true)
                                if (next.isNotEmpty()) {
                                    currentAyahIdExtra = next.first().id
                                    passage = next
                                }
                            }
                        }
                    },
                    onPreviousAyah = {
                        primaryAyah?.let { current ->
                            scope.launch {
                                val prev = app.repository.stepSequentialAyah(current.id, forward = false)
                                if (prev.isNotEmpty()) {
                                    currentAyahIdExtra = prev.first().id
                                    passage = prev
                                }
                            }
                        }
                    },
                    onToggleFavorite = {
                        primaryAyah?.let { scope.launch { app.repository.toggleFavorite(it.id) } }
                    },
                    onSalawatTap = {
                        scope.launch {
                            app.preferences.incrementSalawatCount()
                            Toast.makeText(
                                this@LockScreenAyahActivity,
                                "تقبّل الله صلاتك على محمد وآله",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    onCopyAyah = { copyPassage(passage) },
                    onShareAyah = { sharePassage(passage) },
                    onDismissToUnlock = { dismissAndUnlock() }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        currentAyahIdExtra = intent.getIntExtra(EXTRA_PRIMARY_AYAH_ID, -1)
    }

    private fun configureLockScreenWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun dismissAndUnlock() {
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (keyguardManager.isKeyguardLocked) {
            keyguardManager.requestDismissKeyguard(
                this,
                object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() {
                        finish()
                    }

                    override fun onDismissCancelled() {
                        finish()
                    }

                    override fun onDismissError() {
                        finish()
                    }
                }
            )
        } else {
            finish()
        }
    }

    private fun formatPassageForShare(passage: List<AyahEntity>): String {
        if (passage.isEmpty()) return ""
        val first = passage.first()
        val last = passage.last()
        val versesText = passage.joinToString(" ۝ ") { it.uthmaniText }
        val rangeLabel = if (first.ayahNumber == last.ayahNumber) {
            "الآية ${HijriDateFormatter.toArabicDigits(first.ayahNumber)}"
        } else {
            "الآيات ${HijriDateFormatter.toArabicDigits(first.ayahNumber)}-${HijriDateFormatter.toArabicDigits(last.ayahNumber)}"
        }
        return "﴿ $versesText ﴾\n\nسورة ${first.surahName} • $rangeLabel\n— تطبيق آية"
    }

    private fun copyPassage(passage: List<AyahEntity>) {
        val text = formatPassageForShare(passage)
        if (text.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("آية قرآنية", text))
        Toast.makeText(this, "تم نسخ الآية الكريمة", Toast.LENGTH_SHORT).show()
    }

    private fun sharePassage(passage: List<AyahEntity>) {
        val text = formatPassageForShare(passage)
        if (text.isBlank()) return
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(sendIntent, "مشاركة الآية"))
    }

    companion object {
        const val EXTRA_PRIMARY_AYAH_ID = "extra_primary_ayah_id"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LockScreenOverlayContent(
    passage: List<AyahEntity>,
    settings: AyahSettings,
    isFavorite: Boolean,
    onNextAyah: () -> Unit,
    onPreviousAyah: () -> Unit,
    onToggleFavorite: () -> Unit,
    onSalawatTap: () -> Unit,
    onCopyAyah: () -> Unit,
    onShareAyah: () -> Unit,
    onDismissToUnlock: () -> Unit
) {
    var showTafsirSheet by remember { mutableStateOf(false) }
    var dragAccumulator by remember { mutableFloatStateOf(0f) }

    val verseTextColor = when (settings.textColorTheme) {
        TextColorTheme.IVORY -> IvoryWhite
        TextColorTheme.GOLD -> ChampagneGold
        TextColorTheme.EMERALD -> Color(0xFF9DE3C7)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (settings.amoledMode || settings.backgroundPreset == BackgroundPreset.AMOLED_BLACK) AmoledBlack else EmeraldPrimary)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (dragAccumulator < -140f) {
                            onDismissToUnlock()
                        }
                        dragAccumulator = 0f
                    },
                    onVerticalDrag = { _, dragAmount ->
                        dragAccumulator += dragAmount
                    }
                )
            }
    ) {
        // Offline Curated Wallpaper / Custom Gallery Background / AMOLED Black
        LockScreenBackgroundLayer(settings = settings)

        // Subtle Islamic Vector Geometric Filigree
        if (!settings.amoledMode && settings.backgroundPreset != BackgroundPreset.AMOLED_BLACK) {
            IslamicPatternCanvas()
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Minimalist Digital Clock + Hijri/Gregorian Date + Quranic Reminder
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 18.dp)
            ) {
                Text(
                    text = HijriDateFormatter.formatCurrentClock(),
                    color = IvoryWhite,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Light
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = HijriDateFormatter.formatHijriAndGregorianDate(),
                    color = IvoryMuted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "«${stringResource(R.string.lockscreen_reminder)}»",
                    color = ChampagneGold,
                    fontSize = 15.sp,
                    fontFamily = UthmaniFontFamily,
                    textAlign = TextAlign.Center
                )
            }

            // Center: Spacious Uthmani Ayah + Surah Citation + Salawat Reminder
            val primary = passage.firstOrNull()
            if (primary != null) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.Center
                ) {
                    val fullVerse = passage.joinToString(" ۝ ") { it.uthmaniText }
                    Text(
                        text = fullVerse,
                        color = verseTextColor,
                        fontFamily = UthmaniFontFamily,
                        fontSize = settings.fontSizeSp.sp,
                        lineHeight = (settings.fontSizeSp * 1.75f).sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(22.dp))

                    val last = passage.last()
                    val ayahBadge = if (primary.ayahNumber == last.ayahNumber) {
                        "سورة ${primary.surahName} • الآية ${HijriDateFormatter.toArabicDigits(primary.ayahNumber)}"
                    } else {
                        "سورة ${primary.surahName} • الآيات ${HijriDateFormatter.toArabicDigits(primary.ayahNumber)}-${HijriDateFormatter.toArabicDigits(last.ayahNumber)}"
                    }

                    Surface(
                        color = EmeraldSurface.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = ayahBadge,
                            color = ChampagneGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                        )
                    }

                    if (settings.salawatReminderEnabled) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = stringResource(R.string.salawat_reminder),
                            color = IvoryMuted.copy(alpha = 0.9f),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSalawatTap() }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Bottom Glassmorphic Action Bar
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    color = Color(0x99062C22),
                    shape = RoundedCornerShape(22.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.28f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onPreviousAyah) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                                contentDescription = "الآية السابقة",
                                tint = IvoryWhite
                            )
                        }
                        IconButton(onClick = onToggleFavorite) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "حفظ في المفضلة",
                                tint = if (isFavorite) ChampagneGold else IvoryWhite
                            )
                        }
                        Surface(
                            color = ChampagneGold.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { showTafsirSheet = true }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.AutoStories,
                                    contentDescription = null,
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = "تأمل الآية",
                                    color = ChampagneGold,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        IconButton(onClick = onCopyAyah) {
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = "نسخ الآية",
                                tint = IvoryWhite
                            )
                        }
                        IconButton(onClick = onShareAyah) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = "مشاركة الآية",
                                tint = IvoryWhite
                            )
                        }
                        IconButton(onClick = onNextAyah) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                                contentDescription = "الآية التالية",
                                tint = IvoryWhite
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { onDismissToUnlock() }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LockOpen,
                        contentDescription = null,
                        tint = IvoryMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = "اسحب للأعلى أو اضغط لفتح الهاتف",
                        color = IvoryMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Concise Tafsir Bottom Sheet ("تأمل الآية") without leaving the lock screen
        if (showTafsirSheet && passage.isNotEmpty()) {
            ModalBottomSheet(
                onDismissRequest = { showTafsirSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = if (settings.amoledMode) AmoledBlack else EmeraldPrimary,
                contentColor = IvoryWhite
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "التفسير الميسّر",
                        color = ChampagneGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = ChampagneGold.copy(alpha = 0.25f))
                    Spacer(modifier = Modifier.height(16.dp))

                    passage.forEach { ayah ->
                        Text(
                            text = "﴿ ${ayah.uthmaniText} ﴾",
                            color = IvoryWhite,
                            fontFamily = UthmaniFontFamily,
                            fontSize = 19.sp,
                            lineHeight = 32.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = ayah.tafsirMuyassar,
                            color = IvoryMuted,
                            fontSize = 15.sp,
                            lineHeight = 26.sp
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun LockScreenBackgroundLayer(settings: AyahSettings) {
    if (settings.amoledMode || settings.backgroundPreset == BackgroundPreset.AMOLED_BLACK) {
        Box(modifier = Modifier.fillMaxSize().background(AmoledBlack))
        return
    }

    if (settings.backgroundPreset == BackgroundPreset.CUSTOM_GALLERY && !settings.customBackgroundPath.isNullOrBlank()) {
        val file = remember(settings.customBackgroundPath) { File(settings.customBackgroundPath) }
        val bitmap = remember(settings.customBackgroundPath) {
            if (file.exists()) BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() else null
        }
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xB3000000), Color(0x88000000), Color(0xCC000000))
                        )
                    )
            )
            return
        }
    }

    val drawableRes = when (settings.backgroundPreset) {
        BackgroundPreset.NIGHT_SKY -> R.drawable.bg_night_sky
        BackgroundPreset.MOUNTAINS -> R.drawable.bg_mountains
        BackgroundPreset.EMERALD_ARABESQUE, BackgroundPreset.CUSTOM_GALLERY -> R.drawable.bg_arabesque
        BackgroundPreset.AMOLED_BLACK -> null
    }

    if (drawableRes != null) {
        Image(
            painter = painterResource(id = drawableRes),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0x99062C22), Color(0x73062C22), Color(0xCC041B15))
                    )
                )
        )
    }
}
