package com.ayah.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ayah.app.data.local.dao.AdhkarDao
import com.ayah.app.data.local.dao.AyahDao
import com.ayah.app.data.local.entity.AdhkarEntity
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.local.entity.AyahFtsEntity
import com.ayah.app.data.local.entity.AyahHistoryEntity
import com.ayah.app.data.local.entity.FavoriteAyahEntity
import com.ayah.app.data.local.entity.SurahEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(
    entities = [
        SurahEntity::class,
        AyahEntity::class,
        AyahFtsEntity::class,
        AyahHistoryEntity::class,
        FavoriteAyahEntity::class,
        AdhkarEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AyahDatabase : RoomDatabase() {
    abstract fun ayahDao(): AyahDao
    abstract fun adhkarDao(): AdhkarDao

    companion object {
        @Volatile
        private var INSTANCE: AyahDatabase? = null

        fun getInstance(context: Context): AyahDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): AyahDatabase {
            val initScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            return Room.databaseBuilder(
                appContext,
                AyahDatabase::class.java,
                "ayah_offline_quran.db"
            )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        initScope.launch {
                            INSTANCE?.let { DatabasePrepopulator.populateIfNeeded(appContext, it) }
                        }
                    }
                })
                .build()
        }
    }
}
