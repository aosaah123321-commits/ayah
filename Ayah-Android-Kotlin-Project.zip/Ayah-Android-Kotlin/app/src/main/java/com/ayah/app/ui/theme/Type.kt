package com.ayah.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Drop KFGQPC_Uthmanic_Hafs.ttf & IBM_Plex_Sans_Arabic.ttf into res/font/
 * and load via Font(R.font.uthmanic_hafs) for production Mushaf rendering.
 */
val UthmaniFontFamily: FontFamily = FontFamily.Serif
val ArabicUiFontFamily: FontFamily = FontFamily.SansSerif

val AyahTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = UthmaniFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 30.sp,
        lineHeight = 52.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = ArabicUiFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 30.sp
    ),
    titleMedium = TextStyle(
        fontFamily = ArabicUiFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = ArabicUiFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 26.sp
    ),
    labelMedium = TextStyle(
        fontFamily = ArabicUiFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 18.sp
    )
)
