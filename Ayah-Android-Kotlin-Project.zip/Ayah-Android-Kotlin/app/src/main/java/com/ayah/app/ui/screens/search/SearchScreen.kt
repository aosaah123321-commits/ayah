package com.ayah.app.ui.screens.search

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.ui.theme.UthmaniFontFamily
import com.ayah.app.util.HijriDateFormatter

@Composable
fun SearchScreen(
    query: String,
    results: List<AyahEntity>,
    onQueryChange: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldPrimary)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text(
            text = "البحث الفوري في القرآن",
            color = ChampagneGold,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "بحث محلي فوري (FTS4) بدون تشكيل مع عرض النص العثماني الأصلي",
            color = IvoryMuted,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("ابحث بكلمة أو اسم سورة (مثال: تطمئن القلوب)", color = IvoryMuted) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = ChampagneGold) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ChampagneGold,
                unfocusedBorderColor = ChampagneGold.copy(alpha = 0.35f),
                focusedTextColor = IvoryWhite,
                unfocusedTextColor = IvoryWhite,
                focusedContainerColor = EmeraldSurface,
                unfocusedContainerColor = EmeraldSurface
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(results, key = { it.id }) { ayah ->
                Surface(
                    color = EmeraldSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.22f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = ayah.uthmaniText,
                            color = IvoryWhite,
                            fontFamily = UthmaniFontFamily,
                            fontSize = 20.sp,
                            lineHeight = 34.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "سورة ${ayah.surahName} • الآية ${HijriDateFormatter.toArabicDigits(ayah.ayahNumber)}",
                            color = ChampagneGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = ayah.tafsirMuyassar,
                            color = IvoryMuted,
                            fontSize = 13.sp,
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }
    }
}
