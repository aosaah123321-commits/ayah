package com.ayah.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "ayah_history",
    indices = [Index(value = ["shown_at_ms"])]
)
data class AyahHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "history_id")
    val historyId: Long = 0,
    @ColumnInfo(name = "ayah_id")
    val ayahId: Int,
    @ColumnInfo(name = "shown_at_ms")
    val shownAtMs: Long,
    @ColumnInfo(name = "trigger_source")
    val triggerSource: String
)

@Entity(tableName = "favorite_ayahs")
data class FavoriteAyahEntity(
    @PrimaryKey
    @ColumnInfo(name = "ayah_id")
    val ayahId: Int,
    @ColumnInfo(name = "saved_at_ms")
    val savedAtMs: Long
)

@Entity(
    tableName = "adhkar",
    indices = [Index(value = ["category"])]
)
data class AdhkarEntity(
    @PrimaryKey
    @ColumnInfo(name = "dhikr_id")
    val id: Int,
    @ColumnInfo(name = "category")
    val category: String,
    @ColumnInfo(name = "category_title")
    val categoryTitle: String,
    @ColumnInfo(name = "text")
    val text: String,
    @ColumnInfo(name = "reference")
    val reference: String,
    @ColumnInfo(name = "target_count")
    val targetCount: Int,
    @ColumnInfo(name = "virtue")
    val virtue: String
)
