package com.ayah.app.util

import java.time.LocalDate
import java.time.LocalTime
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField
import java.util.Locale

object HijriDateFormatter {
    private val ARABIC_LOCALE = Locale("ar")
    private val HIJRI_MONTHS = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private val EASTERN_DIGITS = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

    fun toArabicDigits(input: Any): String {
        val raw = input.toString()
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            if (ch in '0'..'9') sb.append(EASTERN_DIGITS[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    fun formatCurrentClock(): String {
        val now = LocalTime.now()
        val formatter = DateTimeFormatter.ofPattern("h:mm", ARABIC_LOCALE)
        return toArabicDigits(now.format(formatter))
    }

    fun formatHijriAndGregorianDate(): String {
        val gregorian = LocalDate.now()
        val hijri = HijrahDate.from(gregorian)
        val hDay = hijri.get(ChronoField.DAY_OF_MONTH)
        val hMonthIndex = (hijri.get(ChronoField.MONTH_OF_YEAR) - 1).coerceIn(0, 11)
        val hYear = hijri.get(ChronoField.YEAR)
        val dayName = gregorian.format(DateTimeFormatter.ofPattern("EEEE", ARABIC_LOCALE))
        val gregStr = gregorian.format(DateTimeFormatter.ofPattern("d MMMM", ARABIC_LOCALE))
        return "$dayName • ${toArabicDigits(hDay)} ${HIJRI_MONTHS[hMonthIndex]} ${toArabicDigits(hYear)} هـ • ${toArabicDigits(gregStr)}"
    }
}
