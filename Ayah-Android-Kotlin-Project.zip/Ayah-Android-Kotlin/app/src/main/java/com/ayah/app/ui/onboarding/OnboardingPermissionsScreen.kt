package com.ayah.app.ui.onboarding

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.util.OemPermissionHelper

@Composable
fun OnboardingPermissionsScreen(
    onComplete: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val detectedOem = remember { OemPermissionHelper.detectOem() }

    var hasOverlayPermission by remember { mutableStateOf(OemPermissionHelper.canDrawOverlays(context)) }
    var ignoringBattery by remember { mutableStateOf(OemPermissionHelper.isIgnoringBatteryOptimizations(context)) }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = OemPermissionHelper.canDrawOverlays(context)
                ignoringBattery = OemPermissionHelper.isIgnoringBatteryOptimizations(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldPrimary)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "تهيئة الظهور على شاشة القفل",
            color = ChampagneGold,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "لضمان عمل تطبيق «آية» بثبات تام دون توقف من أنظمة توفير الطاقة في هواتف شاومي وسامسونج وهواوي وبكسل، يُرجى تفعيل الأذونات التالية:",
            color = IvoryMuted,
            fontSize = 14.sp,
            lineHeight = 22.sp
        )

        PermissionStepCard(
            title = "١. الظهور فوق التطبيقات الأخرى (Overlay)",
            description = "يسمح بعرض الآية الكريمة فور إضاءة الشاشة قبل فتح قفل الهاتف.",
            granted = hasOverlayPermission,
            icon = Icons.Rounded.Layers,
            actionLabel = if (hasOverlayPermission) "تم التفعيل" else "منح الإذن",
            onClick = { context.startActivity(OemPermissionHelper.createOverlayPermissionIntent(context)) }
        )

        PermissionStepCard(
            title = "٢. استثناء تحسين البطارية",
            description = "يمنع النظام من إغلاق خدمة مراقبة الشاشة في الخلفية أثناء السكون.",
            granted = ignoringBattery,
            icon = Icons.Rounded.BatteryChargingFull,
            actionLabel = if (ignoringBattery) "تم الاستثناء" else "استثناء التطبيق",
            onClick = { context.startActivity(OemPermissionHelper.createIgnoreBatteryOptimizationIntent(context)) }
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            PermissionStepCard(
                title = "٣. إذن الإشعار الصامت (Android 13+)",
                description = "مطلوب لتشغيل الخدمة الأمامية بصمت تام دون أي إزعاج.",
                granted = false,
                icon = Icons.Rounded.NotificationsNone,
                actionLabel = "السماح بالإشعار الصامت",
                onClick = { notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            )
        }

        // Device-specific OEM guidance
        Surface(
            color = EmeraldSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.25f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Security, contentDescription = null, tint = ChampagneGold)
                    Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                    Text(
                        text = "إرشادات جهازك: ${detectedOem.displayNameAr}",
                        color = IvoryWhite,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = detectedOem.guidanceAr,
                    color = IvoryMuted,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { OemPermissionHelper.openOemAutoStartSettings(context) },
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
                ) {
                    Text("فتح إعدادات التشغيل التلقائي للجهاز")
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onComplete,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = ChampagneGold,
                contentColor = EmeraldPrimary
            ),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                text = "ابدأ رحلتك مع آية",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
private fun PermissionStepCard(
    title: String,
    description: String,
    granted: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    actionLabel: String,
    onClick: () -> Unit
) {
    Surface(
        color = EmeraldSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (granted) ChampagneGold else ChampagneGold.copy(alpha = 0.22f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(icon, contentDescription = null, tint = ChampagneGold)
                    Spacer(modifier = Modifier.padding(horizontal = 6.dp))
                    Text(text = title, color = IvoryWhite, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
                if (granted) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = "مفعّل", tint = ChampagneGold)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = description, color = IvoryMuted, fontSize = 13.sp, lineHeight = 20.sp)
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onClick,
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
            ) {
                Text(actionLabel)
            }
        }
    }
}
