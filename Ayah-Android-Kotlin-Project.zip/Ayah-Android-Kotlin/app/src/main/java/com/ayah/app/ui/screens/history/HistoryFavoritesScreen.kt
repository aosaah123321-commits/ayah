package com.ayah.app.ui.screens.history

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayah.app.data.local.dao.AyahHistoryRecord
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.ui.theme.UthmaniFontFamily
import com.ayah.app.util.HijriDateFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryFavoritesScreen(
    favorites: List<AyahEntity>,
    history: List<AyahHistoryRecord>,
    onToggleFavorite: (Int) -> Unit,
    onClearHistory: () -> Unit
) {
    var activeTab by remember { mutableIntStateOf(0) }
    val timeFormat = remember { SimpleDateFormat("dd MMM • h:mm a", Locale("ar")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldPrimary)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "السجل والمفضلة",
                color = ChampagneGold,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            if (activeTab == 1 && history.isNotEmpty()) {
                IconButton(onClick = onClearHistory) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "مسح السجل", tint = IvoryMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf("المفضلة (${HijriDateFormatter.toArabicDigits(favorites.size)})", "سجل القفل (${HijriDateFormatter.toArabicDigits(history.size)})")
                .forEachIndexed { idx, label ->
                    val selected = activeTab == idx
                    Surface(
                        color = if (selected) ChampagneGold else EmeraldSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.25f)),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { activeTab = idx }
                    ) {
                        Text(
                            text = label,
                            color = if (selected) EmeraldPrimary else IvoryWhite,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(vertical = 11.dp, horizontal = 12.dp)
                        )
                    }
                }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (activeTab == 0) {
            if (favorites.isEmpty()) {
                EmptyStateBox("لم تقم بحفظ آيات في المفضلة بعد.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(favorites, key = { it.id }) { ayah ->
                        Surface(
                            color = EmeraldSurface,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.22f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = ayah.uthmaniText,
                                    color = IvoryWhite,
                                    fontFamily = UthmaniFontFamily,
                                    fontSize = 20.sp,
                                    lineHeight = 34.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "سورة ${ayah.surahName} • الآية ${HijriDateFormatter.toArabicDigits(ayah.ayahNumber)}",
                                        color = ChampagneGold,
                                        fontSize = 13.sp
                                    )
                                    IconButton(onClick = { onToggleFavorite(ayah.id) }) {
                                        Icon(Icons.Rounded.Favorite, contentDescription = "إزالة من المفضلة", tint = ChampagneGold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (history.isEmpty()) {
                EmptyStateBox("سجل الآيات المعروضة على شاشة القفل فارغ حالياً.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(history, key = { it.historyId }) { item ->
                        Surface(
                            color = EmeraldSurface,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.18f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = item.uthmaniText,
                                    color = IvoryWhite,
                                    fontFamily = UthmaniFontFamily,
                                    fontSize = 19.sp,
                                    lineHeight = 32.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "سورة ${item.surahName} • الآية ${HijriDateFormatter.toArabicDigits(item.ayahNumber)} • ${timeFormat.format(Date(item.shownAtMs))}",
                                    color = IvoryMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyStateBox(message: String) {
    Surface(
        color = EmeraldSurface,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = message,
            color = IvoryMuted,
            fontSize = 14.sp,
            modifier = Modifier.padding(24.dp)
        )
    }
}
