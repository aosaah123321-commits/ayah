package com.ayah.app.ui.screens.adhkar

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayah.app.ui.MainViewModel
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.ui.theme.UthmaniFontFamily
import com.ayah.app.util.HijriDateFormatter

private data class AdhkarTab(val key: String, val label: String)

private val ADHKAR_TABS = listOf(
    AdhkarTab("MORNING", "أذكار الصباح"),
    AdhkarTab("EVENING", "أذكار المساء"),
    AdhkarTab("SLEEP", "أذكار النوم"),
    AdhkarTab("AFTER_PRAYER", "بعد الصلاة")
)

@Composable
fun AdhkarScreen(viewModel: MainViewModel) {
    var selectedCategory by remember { mutableStateOf("MORNING") }
    val items by viewModel.observeAdhkar(selectedCategory).collectAsState(initial = emptyList())
    val counts = remember { mutableStateMapOf<Int, Int>() }
    val haptic = LocalHapticFeedback.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldPrimary)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text(
            text = "الأذكار اليومية",
            color = ChampagneGold,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "اضغط على أي ذكر لحساب التكرار التفاعلي",
            color = IvoryMuted,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ADHKAR_TABS) { tab ->
                val isSelected = tab.key == selectedCategory
                Surface(
                    color = if (isSelected) ChampagneGold else EmeraldSurface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.3f)),
                    modifier = Modifier.clickable { selectedCategory = tab.key }
                ) {
                    Text(
                        text = tab.label,
                        color = if (isSelected) EmeraldPrimary else IvoryWhite,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.id }) { dhikr ->
                val currentCount = counts[dhikr.id] ?: 0
                val completed = currentCount >= dhikr.targetCount
                Surface(
                    color = EmeraldSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(
                        1.dp,
                        if (completed) ChampagneGold else ChampagneGold.copy(alpha = 0.22f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            counts[dhikr.id] = if (completed) 0 else currentCount + 1
                        }
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = dhikr.text,
                            color = IvoryWhite,
                            fontFamily = UthmaniFontFamily,
                            fontSize = 19.sp,
                            lineHeight = 32.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${dhikr.reference} • ${dhikr.virtue}",
                                color = IvoryMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${HijriDateFormatter.toArabicDigits(currentCount)} / ${HijriDateFormatter.toArabicDigits(dhikr.targetCount)}",
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(start = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
