package com.ayah.app

import android.app.Application
import com.ayah.app.data.local.AyahDatabase
import com.ayah.app.data.local.DatabasePrepopulator
import com.ayah.app.data.preferences.AyahPreferencesRepository
import com.ayah.app.data.repository.QuranRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AyahApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AyahDatabase by lazy { AyahDatabase.getInstance(this) }
    val preferences: AyahPreferencesRepository by lazy { AyahPreferencesRepository(this) }
    val repository: QuranRepository by lazy {
        QuranRepository(
            ayahDao = database.ayahDao(),
            adhkarDao = database.adhkarDao(),
            preferences = preferences
        )
    }

    override fun onCreate() {
        super.onCreate()
        appScope.launch {
            DatabasePrepopulator.populateIfNeeded(this@AyahApplication, database)
        }
    }
}
