package com.ayah.app.data.local

import android.content.Context
import com.ayah.app.data.local.entity.AdhkarEntity
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.local.entity.SurahEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class PrepopulatedSurah(
    val number: Int,
    val name: String,
    val revelationType: String,
    val ayahCount: Int
)

@Serializable
data class PrepopulatedAyah(
    val id: Int,
    val surahNumber: Int,
    val surahName: String,
    val ayahNumber: Int,
    val uthmaniText: String,
    val normalizedText: String? = null,
    val tafsirMuyassar: String,
    val juz: Int = 1,
    val page: Int = 1
)

@Serializable
data class PrepopulatedAdhkar(
    val id: Int,
    val category: String,
    val categoryTitle: String,
    val text: String,
    val reference: String,
    val targetCount: Int,
    val virtue: String
)

@Serializable
data class PrepopulatedQuranPayload(
    val schemaVersion: Int = 1,
    val scriptStandard: String = "KFGQPC_UTHMANI_HAFS",
    val tafsirSource: String = "Al-Tafsir Al-Muyassar",
    val surahs: List<PrepopulatedSurah>,
    val ayahs: List<PrepopulatedAyah>,
    val adhkar: List<PrepopulatedAdhkar> = emptyList()
)

object DatabasePrepopulator {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun populateIfNeeded(context: Context, db: AyahDatabase) = withContext(Dispatchers.IO) {
        val ayahDao = db.ayahDao()
        val adhkarDao = db.adhkarDao()

        if (ayahDao.getAyahCount() > 0 && adhkarDao.count() > 0) {
            return@withContext
        }

        val rawJson = context.assets
            .open("quran_uthmani_muyassar.json")
            .bufferedReader(Charsets.UTF_8)
            .use { it.readText() }

        val payload = json.decodeFromString<PrepopulatedQuranPayload>(rawJson)

        val surahEntities = payload.surahs.map {
            SurahEntity(
                number = it.number,
                name = it.name,
                revelationType = it.revelationType,
                ayahCount = it.ayahCount
            )
        }

        val ayahEntities = payload.ayahs.map { ayah ->
            AyahEntity(
                id = ayah.id,
                surahNumber = ayah.surahNumber,
                surahName = ayah.surahName,
                ayahNumber = ayah.ayahNumber,
                // Preserve exact Uthmani script untouched
                uthmaniText = ayah.uthmaniText,
                normalizedText = ayah.normalizedText
                    ?.takeIf { it.isNotBlank() }
                    ?: ArabicTextNormalizer.normalize(ayah.uthmaniText),
                tafsirMuyassar = ayah.tafsirMuyassar,
                juz = ayah.juz,
                page = ayah.page,
                shownInCycle = false
            )
        }

        val adhkarEntities = payload.adhkar.map { item ->
            AdhkarEntity(
                id = item.id,
                category = item.category,
                categoryTitle = item.categoryTitle,
                text = item.text,
                reference = item.reference,
                targetCount = item.targetCount,
                virtue = item.virtue
            )
        }

        if (surahEntities.isNotEmpty()) ayahDao.insertSurahs(surahEntities)
        if (ayahEntities.isNotEmpty()) ayahDao.insertAyahs(ayahEntities)
        if (adhkarEntities.isNotEmpty()) adhkarDao.insertAll(adhkarEntities)
    }
}
