package com.ayah.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.ayah.app.ui.theme.ChampagneGold
import kotlin.math.cos
import kotlin.math.sin

/**
 * Low-opacity geometric Islamic 8-point star & arabesque lattice rendered via Canvas.
 */
@Composable
fun IslamicPatternCanvas(
    modifier: Modifier = Modifier,
    lineColor: Color = ChampagneGold.copy(alpha = 0.08f)
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val cellSize = 180f
        val cols = (size.width / cellSize).toInt() + 2
        val rows = (size.height / cellSize).toInt() + 2

        for (row in 0..rows) {
            for (col in 0..cols) {
                val cx = col * cellSize
                val cy = row * cellSize
                val radius = cellSize * 0.36f

                val starPath = Path()
                val points = 8
                for (i in 0 until points * 2) {
                    val angle = Math.toRadians((i * 180.0 / points) - 90.0)
                    val r = if (i % 2 == 0) radius else radius * 0.44f
                    val px = cx + (r * cos(angle)).toFloat()
                    val py = cy + (r * sin(angle)).toFloat()
                    if (i == 0) starPath.moveTo(px, py) else starPath.lineTo(px, py)
                }
                starPath.close()
                drawPath(starPath, color = lineColor, style = Stroke(width = 1.2f))
                drawCircle(
                    color = lineColor,
                    radius = radius * 0.18f,
                    center = Offset(cx, cy),
                    style = Stroke(width = 1f)
                )
            }
        }
    }
}
