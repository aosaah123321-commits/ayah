package com.ayah.app.ui.screens.home

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayah.app.R
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.preferences.AyahSettings
import com.ayah.app.ui.lockscreen.LockScreenAyahActivity
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.ui.theme.UthmaniFontFamily
import com.ayah.app.util.HijriDateFormatter

@Composable
fun HomeScreen(
    passage: List<AyahEntity>,
    settings: AyahSettings,
    isFavorite: Boolean,
    cycleProgress: Pair<Int, Int>,
    onToggleLockScreen: (Boolean) -> Unit,
    onRefreshAyah: () -> Unit,
    onToggleFavorite: (Int) -> Unit,
    onSendSalawat: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    var showInlineTafsir by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EmeraldPrimary)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header & Tagline
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = stringResource(R.string.app_name),
                    color = ChampagneGold,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = stringResource(R.string.app_tagline),
                    color = IvoryMuted,
                    fontSize = 13.sp
                )
            }
            OutlinedButton(
                onClick = onOpenSettings,
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
            ) {
                Text("الإعدادات", fontSize = 13.sp)
            }
        }

        // Quick Lock Screen Master Toggle
        Surface(
            color = EmeraldSurface,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.25f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "عرض الآيات على شاشة القفل",
                        color = IvoryWhite,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (settings.isLockScreenEnabled) "مفعّل • يعمل دون إنترنت" else "متوقف مؤقتاً",
                        color = IvoryMuted,
                        fontSize = 12.sp
                    )
                }
                Switch(
                    checked = settings.isLockScreenEnabled,
                    onCheckedChange = onToggleLockScreen,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = EmeraldPrimary,
                        checkedTrackColor = ChampagneGold
                    )
                )
            }
        }

        // Ayah of the Moment Card
        val primary = passage.firstOrNull()
        Surface(
            color = EmeraldSurface,
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "آية اللحظة",
                        color = ChampagneGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row {
                        IconButton(onClick = onRefreshAyah) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "آية أخرى", tint = IvoryWhite)
                        }
                        if (primary != null) {
                            IconButton(onClick = { onToggleFavorite(primary.id) }) {
                                Icon(
                                    imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                                    contentDescription = "حفظ في المفضلة",
                                    tint = if (isFavorite) ChampagneGold else IvoryWhite
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (primary != null) {
                    val verseText = passage.joinToString(" ۝ ") { it.uthmaniText }
                    Text(
                        text = verseText,
                        color = IvoryWhite,
                        fontFamily = UthmaniFontFamily,
                        fontSize = settings.fontSizeSp.sp,
                        lineHeight = (settings.fontSizeSp * 1.75f).sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "سورة ${primary.surahName} • الآية ${HijriDateFormatter.toArabicDigits(primary.ayahNumber)}",
                        color = ChampagneGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = { showInlineTafsir = !showInlineTafsir },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
                        ) {
                            Icon(Icons.Rounded.AutoStories, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(if (showInlineTafsir) "إخفاء التفسير" else "تأمل الآية")
                        }
                        Button(
                            onClick = {
                                val intent = Intent(context, LockScreenAyahActivity::class.java)
                                    .putExtra(LockScreenAyahActivity.EXTRA_PRIMARY_AYAH_ID, primary.id)
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ChampagneGold,
                                contentColor = EmeraldPrimary
                            )
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("معاينة القفل", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (showInlineTafsir) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = ChampagneGold.copy(alpha = 0.22f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = primary.tafsirMuyassar,
                            color = IvoryMuted,
                            fontSize = 14.sp,
                            lineHeight = 24.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Salawat Reminder Card
        if (settings.salawatReminderEnabled) {
            Surface(
                color = EmeraldSurface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تذكير الصلاة على النبي ﷺ وآله",
                        color = ChampagneGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.salawat_reminder),
                        color = IvoryWhite,
                        fontSize = 16.sp,
                        fontFamily = UthmaniFontFamily
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المجموع: ${HijriDateFormatter.toArabicDigits(settings.salawatTotalCount)}",
                            color = IvoryMuted,
                            fontSize = 13.sp
                        )
                        OutlinedButton(
                            onClick = onSendSalawat,
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
                        ) {
                            Text("صلِّ على محمد وآله")
                        }
                    }
                }
            }
        }

        // No-Repeat Cycle Progress + Developer Credit Footer
        Text(
            text = "ختمة التذكير (منع التكرار): ${HijriDateFormatter.toArabicDigits(cycleProgress.first)} من ${HijriDateFormatter.toArabicDigits(cycleProgress.second)} آية",
            color = IvoryMuted,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            text = stringResource(R.string.developer_attribution),
            color = ChampagneGold.copy(alpha = 0.8f),
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        )
    }
}
