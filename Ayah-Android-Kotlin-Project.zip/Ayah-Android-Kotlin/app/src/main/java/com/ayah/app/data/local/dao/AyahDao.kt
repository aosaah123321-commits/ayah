package com.ayah.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.ayah.app.data.local.entity.AdhkarEntity
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.local.entity.AyahHistoryEntity
import com.ayah.app.data.local.entity.FavoriteAyahEntity
import com.ayah.app.data.local.entity.SurahEntity
import kotlinx.coroutines.flow.Flow

data class AyahHistoryRecord(
    val historyId: Long,
    val ayahId: Int,
    val shownAtMs: Long,
    val triggerSource: String,
    val surahNumber: Int,
    val surahName: String,
    val ayahNumber: Int,
    val uthmaniText: String,
    val tafsirMuyassar: String
)

@Dao
interface AyahDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSurahs(surahs: List<SurahEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAyahs(ayahs: List<AyahEntity>)

    @Query("SELECT COUNT(*) FROM ayahs")
    suspend fun getAyahCount(): Int

    @Query("SELECT * FROM surahs ORDER BY surah_number ASC")
    fun observeAllSurahs(): Flow<List<SurahEntity>>

    @Query("SELECT * FROM ayahs WHERE surah_number = :surahNumber ORDER BY ayah_number ASC")
    fun observeAyahsBySurah(surahNumber: Int): Flow<List<AyahEntity>>

    @Query("SELECT * FROM ayahs WHERE ayah_id = :ayahId LIMIT 1")
    suspend fun getAyahById(ayahId: Int): AyahEntity?

    @Query("SELECT * FROM ayahs WHERE ayah_id > :currentAyahId ORDER BY ayah_id ASC LIMIT 1")
    suspend fun getNextSequentialAyah(currentAyahId: Int): AyahEntity?

    @Query("SELECT * FROM ayahs WHERE ayah_id < :currentAyahId ORDER BY ayah_id DESC LIMIT 1")
    suspend fun getPreviousSequentialAyah(currentAyahId: Int): AyahEntity?

    @Query("SELECT * FROM ayahs ORDER BY ayah_id ASC LIMIT 1")
    suspend fun getFirstAyah(): AyahEntity?

    @Query("SELECT * FROM ayahs ORDER BY ayah_id DESC LIMIT 1")
    suspend fun getLastAyah(): AyahEntity?

    // No-Repeat Cycle queries
    @Query("SELECT * FROM ayahs WHERE shown_in_cycle = 0 ORDER BY RANDOM() LIMIT 1")
    suspend fun getRandomUnshownAyah(): AyahEntity?

    @Query("SELECT * FROM ayahs ORDER BY RANDOM() LIMIT 1")
    suspend fun getRandomAyah(): AyahEntity?

    @Query("SELECT COUNT(*) FROM ayahs WHERE shown_in_cycle = 1")
    fun observeShownCycleCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM ayahs")
    fun observeTotalAyahCount(): Flow<Int>

    @Query("UPDATE ayahs SET shown_in_cycle = 1 WHERE ayah_id IN (:ayahIds)")
    suspend fun markAyahsShownInCycle(ayahIds: List<Int>)

    @Query("UPDATE ayahs SET shown_in_cycle = 0")
    suspend fun resetNoRepeatCycle()

    // Short Passage mode: fetch up to 3 consecutive verses from the same Surah
    @Query(
        """
        SELECT * FROM ayahs
        WHERE surah_number = :surahNumber
          AND ayah_number >= :startAyahNumber
          AND ayah_number < :startAyahNumber + 3
        ORDER BY ayah_number ASC
        """
    )
    suspend fun getPassageFromAyah(surahNumber: Int, startAyahNumber: Int): List<AyahEntity>

    // Instant Offline FTS4 Search
    @Query(
        """
        SELECT ayahs.* FROM ayahs
        JOIN ayahs_fts ON ayahs.rowid = ayahs_fts.rowid
        WHERE ayahs_fts MATCH :ftsQuery
        ORDER BY ayahs.ayah_id ASC
        LIMIT :limit
        """
    )
    suspend fun searchAyahsFts(ftsQuery: String, limit: Int = 50): List<AyahEntity>

    // Fallback LIKE search for partial substrings
    @Query(
        """
        SELECT * FROM ayahs
        WHERE normalized_text LIKE '%' || :normalizedQuery || '%'
           OR surah_name LIKE '%' || :normalizedQuery || '%'
        ORDER BY ayah_id ASC
        LIMIT :limit
        """
    )
    suspend fun searchAyahsLike(normalizedQuery: String, limit: Int = 50): List<AyahEntity>

    // Favorites
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: FavoriteAyahEntity)

    @Query("DELETE FROM favorite_ayahs WHERE ayah_id = :ayahId")
    suspend fun removeFavorite(ayahId: Int)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_ayahs WHERE ayah_id = :ayahId)")
    fun observeIsFavorite(ayahId: Int): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_ayahs WHERE ayah_id = :ayahId)")
    suspend fun isFavorite(ayahId: Int): Boolean

    @Query(
        """
        SELECT ayahs.* FROM ayahs
        INNER JOIN favorite_ayahs ON ayahs.ayah_id = favorite_ayahs.ayah_id
        ORDER BY favorite_ayahs.saved_at_ms DESC
        """
    )
    fun observeFavorites(): Flow<List<AyahEntity>>

    // History Log
    @Insert
    suspend fun insertHistory(entry: AyahHistoryEntity)

    @Query("DELETE FROM ayah_history")
    suspend fun clearHistory()

    @Query(
        """
        SELECT h.history_id AS historyId,
               h.ayah_id AS ayahId,
               h.shown_at_ms AS shownAtMs,
               h.trigger_source AS triggerSource,
               a.surah_number AS surahNumber,
               a.surah_name AS surahName,
               a.ayah_number AS ayahNumber,
               a.uthmani_text AS uthmaniText,
               a.tafsir_muyassar AS tafsirMuyassar
        FROM ayah_history h
        INNER JOIN ayahs a ON h.ayah_id = a.ayah_id
        ORDER BY h.shown_at_ms DESC
        LIMIT 200
        """
    )
    fun observeHistory(): Flow<List<AyahHistoryRecord>>
}

@Dao
interface AdhkarDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<AdhkarEntity>)

    @Query("SELECT * FROM adhkar WHERE category = :category ORDER BY dhikr_id ASC")
    fun observeByCategory(category: String): Flow<List<AdhkarEntity>>

    @Query("SELECT COUNT(*) FROM adhkar")
    suspend fun count(): Int
}
