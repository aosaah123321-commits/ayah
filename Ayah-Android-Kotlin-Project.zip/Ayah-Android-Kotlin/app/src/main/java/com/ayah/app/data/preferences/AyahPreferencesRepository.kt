package com.ayah.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.ayahDataStore: DataStore<Preferences> by preferencesDataStore(name = "ayah_settings")

enum class TriggerMode { EVERY_WAKE, EVERY_UNLOCK, INTERVAL }
enum class DisplayMode { SINGLE_AYAH, SHORT_PASSAGE }
enum class TextColorTheme { IVORY, GOLD, EMERALD }
enum class BackgroundPreset { EMERALD_ARABESQUE, NIGHT_SKY, MOUNTAINS, AMOLED_BLACK, CUSTOM_GALLERY }

data class AyahSettings(
    val isLockScreenEnabled: Boolean = true,
    val triggerMode: TriggerMode = TriggerMode.EVERY_WAKE,
    val intervalMinutes: Int = 60,
    val displayMode: DisplayMode = DisplayMode.SINGLE_AYAH,
    val noRepeatEnabled: Boolean = true,
    val quietHoursEnabled: Boolean = false,
    val quietStartMinutes: Int = 23 * 60,
    val quietEndMinutes: Int = 5 * 60 + 30,
    val fontSizeSp: Float = 26f,
    val textColorTheme: TextColorTheme = TextColorTheme.IVORY,
    val amoledMode: Boolean = false,
    val backgroundPreset: BackgroundPreset = BackgroundPreset.EMERALD_ARABESQUE,
    val customBackgroundPath: String? = null,
    val ambientChimeEnabled: Boolean = false,
    val salawatReminderEnabled: Boolean = true,
    val salawatTotalCount: Int = 0,
    val activeAyahId: Int = 2164,
    val lastShownTimestampMs: Long = 0L,
    val onboardingCompleted: Boolean = false
)

class AyahPreferencesRepository(private val context: Context) {

    private object Keys {
        val LOCK_SCREEN_ENABLED = booleanPreferencesKey("lock_screen_enabled")
        val TRIGGER_MODE = stringPreferencesKey("trigger_mode")
        val INTERVAL_MINUTES = intPreferencesKey("interval_minutes")
        val DISPLAY_MODE = stringPreferencesKey("display_mode")
        val NO_REPEAT_ENABLED = booleanPreferencesKey("no_repeat_enabled")
        val QUIET_HOURS_ENABLED = booleanPreferencesKey("quiet_hours_enabled")
        val QUIET_START_MINUTES = intPreferencesKey("quiet_start_minutes")
        val QUIET_END_MINUTES = intPreferencesKey("quiet_end_minutes")
        val FONT_SIZE_SP = floatPreferencesKey("font_size_sp")
        val TEXT_COLOR_THEME = stringPreferencesKey("text_color_theme")
        val AMOLED_MODE = booleanPreferencesKey("amoled_mode")
        val BACKGROUND_PRESET = stringPreferencesKey("background_preset")
        val CUSTOM_BACKGROUND_PATH = stringPreferencesKey("custom_background_path")
        val AMBIENT_CHIME_ENABLED = booleanPreferencesKey("ambient_chime_enabled")
        val SALAWAT_REMINDER_ENABLED = booleanPreferencesKey("salawat_reminder_enabled")
        val SALAWAT_TOTAL_COUNT = intPreferencesKey("salawat_total_count")
        val ACTIVE_AYAH_ID = intPreferencesKey("active_ayah_id")
        val LAST_SHOWN_TIMESTAMP_MS = longPreferencesKey("last_shown_timestamp_ms")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
    }

    val settingsFlow: Flow<AyahSettings> = context.ayahDataStore.data.map { prefs ->
        AyahSettings(
            isLockScreenEnabled = prefs[Keys.LOCK_SCREEN_ENABLED] ?: true,
            triggerMode = prefs[Keys.TRIGGER_MODE]?.let { runCatching { TriggerMode.valueOf(it) }.getOrNull() }
                ?: TriggerMode.EVERY_WAKE,
            intervalMinutes = prefs[Keys.INTERVAL_MINUTES] ?: 60,
            displayMode = prefs[Keys.DISPLAY_MODE]?.let { runCatching { DisplayMode.valueOf(it) }.getOrNull() }
                ?: DisplayMode.SINGLE_AYAH,
            noRepeatEnabled = prefs[Keys.NO_REPEAT_ENABLED] ?: true,
            quietHoursEnabled = prefs[Keys.QUIET_HOURS_ENABLED] ?: false,
            quietStartMinutes = prefs[Keys.QUIET_START_MINUTES] ?: (23 * 60),
            quietEndMinutes = prefs[Keys.QUIET_END_MINUTES] ?: (5 * 60 + 30),
            fontSizeSp = prefs[Keys.FONT_SIZE_SP] ?: 26f,
            textColorTheme = prefs[Keys.TEXT_COLOR_THEME]?.let { runCatching { TextColorTheme.valueOf(it) }.getOrNull() }
                ?: TextColorTheme.IVORY,
            amoledMode = prefs[Keys.AMOLED_MODE] ?: false,
            backgroundPreset = prefs[Keys.BACKGROUND_PRESET]?.let { runCatching { BackgroundPreset.valueOf(it) }.getOrNull() }
                ?: BackgroundPreset.EMERALD_ARABESQUE,
            customBackgroundPath = prefs[Keys.CUSTOM_BACKGROUND_PATH],
            ambientChimeEnabled = prefs[Keys.AMBIENT_CHIME_ENABLED] ?: false,
            salawatReminderEnabled = prefs[Keys.SALAWAT_REMINDER_ENABLED] ?: true,
            salawatTotalCount = prefs[Keys.SALAWAT_TOTAL_COUNT] ?: 0,
            activeAyahId = prefs[Keys.ACTIVE_AYAH_ID] ?: 2164,
            lastShownTimestampMs = prefs[Keys.LAST_SHOWN_TIMESTAMP_MS] ?: 0L,
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false
        )
    }

    suspend fun setLockScreenEnabled(enabled: Boolean) = edit { it[Keys.LOCK_SCREEN_ENABLED] = enabled }
    suspend fun setTriggerMode(mode: TriggerMode) = edit { it[Keys.TRIGGER_MODE] = mode.name }
    suspend fun setIntervalMinutes(minutes: Int) = edit { it[Keys.INTERVAL_MINUTES] = minutes }
    suspend fun setDisplayMode(mode: DisplayMode) = edit { it[Keys.DISPLAY_MODE] = mode.name }
    suspend fun setNoRepeatEnabled(enabled: Boolean) = edit { it[Keys.NO_REPEAT_ENABLED] = enabled }
    suspend fun setQuietHoursEnabled(enabled: Boolean) = edit { it[Keys.QUIET_HOURS_ENABLED] = enabled }
    suspend fun setQuietRange(startMinutes: Int, endMinutes: Int) = edit {
        it[Keys.QUIET_START_MINUTES] = startMinutes
        it[Keys.QUIET_END_MINUTES] = endMinutes
    }
    suspend fun setFontSizeSp(size: Float) = edit { it[Keys.FONT_SIZE_SP] = size }
    suspend fun setTextColorTheme(theme: TextColorTheme) = edit { it[Keys.TEXT_COLOR_THEME] = theme.name }
    suspend fun setAmoledMode(enabled: Boolean) = edit { it[Keys.AMOLED_MODE] = enabled }
    suspend fun setBackgroundPreset(preset: BackgroundPreset) = edit { it[Keys.BACKGROUND_PRESET] = preset.name }
    suspend fun setCustomBackgroundPath(path: String?) = edit {
        if (path == null) it.remove(Keys.CUSTOM_BACKGROUND_PATH) else it[Keys.CUSTOM_BACKGROUND_PATH] = path
    }
    suspend fun setAmbientChimeEnabled(enabled: Boolean) = edit { it[Keys.AMBIENT_CHIME_ENABLED] = enabled }
    suspend fun setSalawatReminderEnabled(enabled: Boolean) = edit { it[Keys.SALAWAT_REMINDER_ENABLED] = enabled }
    suspend fun incrementSalawatCount() = edit {
        val current = it[Keys.SALAWAT_TOTAL_COUNT] ?: 0
        it[Keys.SALAWAT_TOTAL_COUNT] = current + 1
    }
    suspend fun updateActiveAyah(ayahId: Int, shownAtMs: Long) = edit {
        it[Keys.ACTIVE_AYAH_ID] = ayahId
        it[Keys.LAST_SHOWN_TIMESTAMP_MS] = shownAtMs
    }
    suspend fun setOnboardingCompleted(completed: Boolean) = edit { it[Keys.ONBOARDING_COMPLETED] = completed }

    private suspend inline fun edit(crossinline block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.ayahDataStore.edit { block(it) }
    }
}
