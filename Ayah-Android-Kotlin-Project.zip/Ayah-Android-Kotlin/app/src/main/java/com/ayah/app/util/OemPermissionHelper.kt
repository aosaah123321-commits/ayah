package com.ayah.app.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

enum class DeviceOem(val displayNameAr: String, val guidanceAr: String) {
    XIAOMI(
        displayNameAr = "شاومي / ريدمي / بوكو (MIUI / HyperOS)",
        guidanceAr = "فعّل «التشغيل التلقائي» (Autostart) و«العرض على شاشة القفل» من إعدادات أذونات التطبيق."
    ),
    SAMSUNG(
        displayNameAr = "سامسونج (One UI)",
        guidanceAr = "اختر «غير مقيد» (Unrestricted) في إعدادات البطارية، وتأكد من إيقاف وضع السكون العميق للتطبيق."
    ),
    HUAWEI(
        displayNameAr = "هواوي / أونر (EMUI / MagicOS)",
        guidanceAr = "انتقل إلى إدارة البطارية -> تشغيل التطبيقات -> اختر الإدارة يدوياً وفعّل التشغيل التلقائي."
    ),
    PIXEL_STOCK(
        displayNameAr = "أندرويد الخام / جوجل بكسل",
        guidanceAr = "امنح إذن «الظهور فوق التطبيقات الأخرى» واستثنِ التطبيق من تحسين البطارية."
    )
}

object OemPermissionHelper {

    fun detectOem(): DeviceOem {
        val manufacturer = Build.MANUFACTURER.lowercase()
        return when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco") -> DeviceOem.XIAOMI
            manufacturer.contains("samsung") -> DeviceOem.SAMSUNG
            manufacturer.contains("huawei") || manufacturer.contains("honor") -> DeviceOem.HUAWEI
            else -> DeviceOem.PIXEL_STOCK
        }
    }

    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun createOverlayPermissionIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun createIgnoreBatteryOptimizationIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun openOemAutoStartSettings(context: Context) {
        val candidates = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity"))
                .putExtra("extra_pkgname", context.packageName),
            Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
            Intent().setComponent(ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity")),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        )
        for (intent in candidates) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val resolved = context.packageManager.resolveActivity(intent, 0)
            if (resolved != null) {
                runCatching {
                    context.startActivity(intent)
                    return
                }
            }
        }
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
