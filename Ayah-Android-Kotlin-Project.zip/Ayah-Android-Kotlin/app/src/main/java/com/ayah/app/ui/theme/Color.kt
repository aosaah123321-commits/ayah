package com.ayah.app.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF062C22)
val EmeraldSurface = Color(0xFF0A3D2E)
val EmeraldElevated = Color(0xFF0F4C3A)
val ChampagneGold = Color(0xFFC5A059)
val ChampagneGoldBright = Color(0xFFD4AF37)
val IvoryWhite = Color(0xFFF8F5EE)
val IvoryMuted = Color(0xFFC8C2B6)
val AmoledBlack = Color(0xFF000000)
val AmoledSurface = Color(0xFF0B0E0D)
val HairlineBorder = Color(0x26C5A059)
