package com.ayah.app.ui.screens.quran

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.local.entity.SurahEntity
import com.ayah.app.ui.MainViewModel
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite
import com.ayah.app.ui.theme.UthmaniFontFamily
import com.ayah.app.util.HijriDateFormatter

@Composable
fun QuranBrowserScreen(
    surahs: List<SurahEntity>,
    viewModel: MainViewModel
) {
    var selectedSurah by remember { mutableStateOf<SurahEntity?>(null) }

    if (selectedSurah == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(EmeraldPrimary)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "المصحف الشريف",
                color = ChampagneGold,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "فهرس السور الكامل (١١٤ سورة • ٦,٢٣٦ آية) بالرسم العثماني",
                color = IvoryMuted,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(surahs, key = { it.number }) { surah ->
                    Surface(
                        color = EmeraldSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.2f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedSurah = surah }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = HijriDateFormatter.toArabicDigits(surah.number),
                                    color = ChampagneGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    modifier = Modifier.padding(end = 14.dp)
                                )
                                Column {
                                    Text(
                                        text = "سورة ${surah.name}",
                                        color = IvoryWhite,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "${surah.revelationType} • ${HijriDateFormatter.toArabicDigits(surah.ayahCount)} آيات",
                                        color = IvoryMuted,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        val currentSurah = selectedSurah!!
        val ayahs by viewModel.observeSurahAyahs(currentSurah.number).collectAsState(initial = emptyList())
        val favorites by viewModel.favorites.collectAsState()
        val favoriteIds = remember(favorites) { favorites.map { it.id }.toSet() }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(EmeraldPrimary)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = { selectedSurah = null }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "العودة للفهرس", tint = ChampagneGold)
                }
                Column {
                    Text(
                        text = "سورة ${currentSurah.name}",
                        color = ChampagneGold,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentSurah.revelationType} • ${HijriDateFormatter.toArabicDigits(currentSurah.ayahCount)} آيات",
                        color = IvoryMuted,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (ayahs.isEmpty()) {
                Surface(
                    color = EmeraldSurface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "لتضمين النص الكامل لجميع السور الـ ١١٤ محلياً، شغّل سكربت scripts/prepare_quran_db.py لتعبئة ملف assets/quran_uthmani_muyassar.json.",
                        color = IvoryMuted,
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(ayahs, key = { it.id }) { ayah: AyahEntity ->
                        val isFav = favoriteIds.contains(ayah.id)
                        Surface(
                            color = EmeraldSurface,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.18f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "${ayah.uthmaniText} ﴿${HijriDateFormatter.toArabicDigits(ayah.ayahNumber)}﴾",
                                    color = IvoryWhite,
                                    fontFamily = UthmaniFontFamily,
                                    fontSize = 22.sp,
                                    lineHeight = 38.sp,
                                    textAlign = TextAlign.Start
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(color = ChampagneGold.copy(alpha = 0.15f))
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = ayah.tafsirMuyassar,
                                        color = IvoryMuted,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { viewModel.toggleFavorite(ayah.id) }) {
                                        Icon(
                                            imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                                            contentDescription = "حفظ الآية",
                                            tint = if (isFav) ChampagneGold else IvoryMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
