package com.ayah.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.ayah.app.ui.onboarding.OnboardingPermissionsScreen
import com.ayah.app.ui.screens.adhkar.AdhkarScreen
import com.ayah.app.ui.screens.history.HistoryFavoritesScreen
import com.ayah.app.ui.screens.home.HomeScreen
import com.ayah.app.ui.screens.quran.QuranBrowserScreen
import com.ayah.app.ui.screens.search.SearchScreen
import com.ayah.app.ui.screens.settings.SettingsScreen
import com.ayah.app.ui.theme.AmoledBlack
import com.ayah.app.ui.theme.AyahTheme
import com.ayah.app.ui.theme.ChampagneGold
import com.ayah.app.ui.theme.EmeraldPrimary
import com.ayah.app.ui.theme.EmeraldSurface
import com.ayah.app.ui.theme.IvoryMuted
import com.ayah.app.ui.theme.IvoryWhite

private enum class MainDestination(val label: String, val icon: ImageVector) {
    HOME("الرئيسية", Icons.Rounded.Home),
    QURAN("المصحف", Icons.Rounded.MenuBook),
    ADHKAR("الأذكار", Icons.Rounded.VolunteerActivism),
    HISTORY("السجل والمفضلة", Icons.Rounded.Bookmark),
    SEARCH("البحث", Icons.Rounded.Search)
}

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.settings.collectAsState()
            val passage by viewModel.activePassage.collectAsState()
            val surahs by viewModel.surahs.collectAsState()
            val favorites by viewModel.favorites.collectAsState()
            val history by viewModel.history.collectAsState()
            val cycleProgress by viewModel.cycleProgress.collectAsState()
            val searchQuery by viewModel.searchQuery.collectAsState()
            val searchResults by viewModel.searchResults.collectAsState()

            val primaryId = passage.firstOrNull()?.id ?: -1
            val isFavorite by viewModel.observeIsFavorite(primaryId).collectAsState(initial = false)

            var currentDestination by remember { mutableStateOf(MainDestination.HOME) }
            var showSettings by remember { mutableStateOf(false) }
            var showPermissions by remember { mutableStateOf(false) }

            AyahTheme(amoledMode = settings.amoledMode) {
                if (!settings.onboardingCompleted || showPermissions) {
                    OnboardingPermissionsScreen(
                        onComplete = {
                            viewModel.completeOnboarding()
                            showPermissions = false
                        }
                    )
                } else if (showSettings) {
                    Scaffold(
                        containerColor = if (settings.amoledMode) AmoledBlack else EmeraldPrimary
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            SettingsScreen(
                                settings = settings,
                                viewModel = viewModel,
                                onOpenPermissions = { showPermissions = true }
                            )
                        }
                    }
                } else {
                    Scaffold(
                        containerColor = if (settings.amoledMode) AmoledBlack else EmeraldPrimary,
                        bottomBar = {
                            NavigationBar(
                                containerColor = if (settings.amoledMode) AmoledBlack else EmeraldSurface,
                                contentColor = IvoryWhite
                            ) {
                                MainDestination.entries.forEach { dest ->
                                    val selected = currentDestination == dest
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { currentDestination = dest },
                                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                                        label = { Text(dest.label, maxLines = 1) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = ChampagneGold,
                                            selectedTextColor = ChampagneGold,
                                            unselectedIconColor = IvoryMuted,
                                            unselectedTextColor = IvoryMuted,
                                            indicatorColor = ChampagneGold.copy(alpha = 0.14f)
                                        )
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (currentDestination) {
                                MainDestination.HOME -> HomeScreen(
                                    passage = passage,
                                    settings = settings,
                                    isFavorite = isFavorite,
                                    cycleProgress = cycleProgress,
                                    onToggleLockScreen = viewModel::setLockScreenEnabled,
                                    onRefreshAyah = viewModel::refreshRandomAyah,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onSendSalawat = viewModel::sendSalawatBlessings,
                                    onOpenSettings = { showSettings = true }
                                )

                                MainDestination.QURAN -> QuranBrowserScreen(
                                    surahs = surahs,
                                    viewModel = viewModel
                                )

                                MainDestination.ADHKAR -> AdhkarScreen(viewModel = viewModel)

                                MainDestination.HISTORY -> HistoryFavoritesScreen(
                                    favorites = favorites,
                                    history = history,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onClearHistory = viewModel::clearHistory
                                )

                                MainDestination.SEARCH -> SearchScreen(
                                    query = searchQuery,
                                    results = searchResults,
                                    onQueryChange = viewModel::updateSearchQuery
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
