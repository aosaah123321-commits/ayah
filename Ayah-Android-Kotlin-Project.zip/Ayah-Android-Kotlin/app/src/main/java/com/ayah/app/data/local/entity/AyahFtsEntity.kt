package com.ayah.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Fts4

@Fts4(contentEntity = AyahEntity::class)
@Entity(tableName = "ayahs_fts")
data class AyahFtsEntity(
    @ColumnInfo(name = "normalized_text")
    val normalizedText: String,
    @ColumnInfo(name = "surah_name")
    val surahName: String
)
