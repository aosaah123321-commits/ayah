package com.ayah.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ayah.app.AyahApplication
import com.ayah.app.data.local.dao.AyahHistoryRecord
import com.ayah.app.data.local.entity.AdhkarEntity
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.local.entity.SurahEntity
import com.ayah.app.data.preferences.AyahSettings
import com.ayah.app.data.preferences.BackgroundPreset
import com.ayah.app.data.preferences.DisplayMode
import com.ayah.app.data.preferences.TextColorTheme
import com.ayah.app.data.preferences.TriggerMode
import com.ayah.app.service.ScreenMonitorService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as AyahApplication
    private val repo = app.repository
    private val prefs = app.preferences

    val settings: StateFlow<AyahSettings> = repo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AyahSettings())

    val surahs: StateFlow<List<SurahEntity>> = repo.allSurahsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<AyahEntity>> = repo.favoritesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<AyahHistoryRecord>> = repo.historyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cycleProgress: StateFlow<Pair<Int, Int>> = combine(
        repo.shownCycleCountFlow,
        repo.totalAyahCountFlow
    ) { shown, total -> shown to total }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0 to 0)

    private val _activePassage = MutableStateFlow<List<AyahEntity>>(emptyList())
    val activePassage: StateFlow<List<AyahEntity>> = _activePassage.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<AyahEntity>>(emptyList())
    val searchResults: StateFlow<List<AyahEntity>> = _searchResults.asStateFlow()

    init {
        viewModelScope.launch {
            settings.collect { currentSettings ->
                val primary = repo.getAyahOrFallback(currentSettings.activeAyahId)
                if (primary != null) {
                    _activePassage.value = repo.getPassageForSettings(primary, currentSettings.displayMode)
                }
            }
        }
    }

    fun observeSurahAyahs(surahNumber: Int): Flow<List<AyahEntity>> =
        repo.observeSurahAyahs(surahNumber)

    fun observeAdhkar(category: String): Flow<List<AdhkarEntity>> =
        repo.observeAdhkar(category)

    fun observeIsFavorite(ayahId: Int): Flow<Boolean> =
        repo.observeIsFavorite(ayahId)

    fun setLockScreenEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setLockScreenEnabled(enabled)
            if (enabled) ScreenMonitorService.start(app) else ScreenMonitorService.stop(app)
        }
    }

    fun refreshRandomAyah() {
        viewModelScope.launch {
            val next = repo.pickAndRecordNextAyah("MANUAL_HOME")
            if (next.isNotEmpty()) _activePassage.value = next
        }
    }

    fun toggleFavorite(ayahId: Int) {
        viewModelScope.launch { repo.toggleFavorite(ayahId) }
    }

    fun sendSalawatBlessings() {
        viewModelScope.launch { prefs.incrementSalawatCount() }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        viewModelScope.launch(Dispatchers.IO) {
            _searchResults.value = repo.searchOffline(query)
        }
    }

    fun setTriggerMode(mode: TriggerMode) = viewModelScope.launch { prefs.setTriggerMode(mode) }
    fun setIntervalMinutes(minutes: Int) = viewModelScope.launch { prefs.setIntervalMinutes(minutes) }
    fun setDisplayMode(mode: DisplayMode) = viewModelScope.launch { prefs.setDisplayMode(mode) }
    fun setNoRepeatEnabled(enabled: Boolean) = viewModelScope.launch { prefs.setNoRepeatEnabled(enabled) }
    fun resetNoRepeatCycle() = viewModelScope.launch { repo.resetNoRepeatCycle() }
    fun setQuietHoursEnabled(enabled: Boolean) = viewModelScope.launch { prefs.setQuietHoursEnabled(enabled) }
    fun setQuietRange(start: Int, end: Int) = viewModelScope.launch { prefs.setQuietRange(start, end) }
    fun setFontSizeSp(size: Float) = viewModelScope.launch { prefs.setFontSizeSp(size) }
    fun setTextColorTheme(theme: TextColorTheme) = viewModelScope.launch { prefs.setTextColorTheme(theme) }
    fun setAmoledMode(enabled: Boolean) = viewModelScope.launch { prefs.setAmoledMode(enabled) }
    fun setBackgroundPreset(preset: BackgroundPreset) = viewModelScope.launch { prefs.setBackgroundPreset(preset) }
    fun setAmbientChimeEnabled(enabled: Boolean) = viewModelScope.launch { prefs.setAmbientChimeEnabled(enabled) }
    fun setSalawatReminderEnabled(enabled: Boolean) = viewModelScope.launch { prefs.setSalawatReminderEnabled(enabled) }
    fun clearHistory() = viewModelScope.launch { repo.clearHistory() }
    fun completeOnboarding() = viewModelScope.launch {
        prefs.setOnboardingCompleted(true)
        if (settings.value.isLockScreenEnabled) ScreenMonitorService.start(app)
    }

    fun saveCustomGalleryBackground(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val targetFile = File(context.filesDir, "custom_lockscreen_bg.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    targetFile.outputStream().use { output -> input.copyTo(output) }
                }
                prefs.setCustomBackgroundPath(targetFile.absolutePath)
                prefs.setBackgroundPreset(BackgroundPreset.CUSTOM_GALLERY)
            }
        }
    }
}
