package com.ayah.app.data.local

object ArabicTextNormalizer {
    private val TASHKEEL_REGEX = Regex("[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640]")
    private val ALEF_REGEX = Regex("[\\u0622\\u0623\\u0625\\u0671]")
    private val WHITESPACE_REGEX = Regex("\\s+")

    /**
     * Normalizes Arabic input strictly for offline FTS indexing and querying.
     * Never modifies the canonical Uthmani text stored in AyahEntity.uthmaniText.
     */
    fun normalize(input: String): String {
        if (input.isBlank()) return ""
        return input
            .replace(TASHKEEL_REGEX, "")
            .replace(ALEF_REGEX, "\u0627")
            .replace('\u0649', '\u064A') // ى -> ي
            .replace('\u0629', '\u0647') // ة -> ه
            .replace('\u0624', '\u0648') // ؤ -> و
            .replace('\u0626', '\u064A') // ئ -> ي
            .replace(WHITESPACE_REGEX, " ")
            .trim()
    }

    fun buildFtsQuery(rawQuery: String): String {
        val normalized = normalize(rawQuery)
        if (normalized.isBlank()) return ""
        return normalized
            .split(" ")
            .filter { it.isNotBlank() }
            .joinToString(" ") { token -> "${token.replace("\"", "")}*" }
    }
}
