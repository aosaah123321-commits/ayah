package com.ayah.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "ayahs",
    indices = [
        Index(value = ["surah_number", "ayah_number"], unique = true),
        Index(value = ["shown_in_cycle"])
    ]
)
data class AyahEntity(
    @PrimaryKey
    @ColumnInfo(name = "ayah_id")
    val id: Int,
    @ColumnInfo(name = "surah_number")
    val surahNumber: Int,
    @ColumnInfo(name = "surah_name")
    val surahName: String,
    @ColumnInfo(name = "ayah_number")
    val ayahNumber: Int,
    @ColumnInfo(name = "uthmani_text")
    val uthmaniText: String,
    @ColumnInfo(name = "normalized_text")
    val normalizedText: String,
    @ColumnInfo(name = "tafsir_muyassar")
    val tafsirMuyassar: String,
    @ColumnInfo(name = "juz")
    val juz: Int,
    @ColumnInfo(name = "page")
    val page: Int,
    @ColumnInfo(name = "shown_in_cycle")
    val shownInCycle: Boolean = false
)
