package com.ayah.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ayah.app.AyahApplication
import com.ayah.app.ui.lockscreen.LockScreenAyahActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class ScreenEventReceiver(
    private val serviceScope: CoroutineScope
) : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_SCREEN_ON && action != Intent.ACTION_USER_PRESENT) {
            return
        }

        val pendingResult = goAsync()
        val app = context.applicationContext as AyahApplication

        serviceScope.launch {
            try {
                if (app.repository.shouldTriggerForEvent(action)) {
                    val passage = app.repository.pickAndRecordNextAyah(
                        triggerSource = if (action == Intent.ACTION_SCREEN_ON) "WAKE" else "UNLOCK"
                    )
                    if (passage.isNotEmpty()) {
                        val launchIntent = Intent(context, LockScreenAyahActivity::class.java).apply {
                            addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK or
                                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                                    Intent.FLAG_ACTIVITY_NO_ANIMATION
                            )
                            putExtra(LockScreenAyahActivity.EXTRA_PRIMARY_AYAH_ID, passage.first().id)
                        }
                        context.startActivity(launchIntent)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
