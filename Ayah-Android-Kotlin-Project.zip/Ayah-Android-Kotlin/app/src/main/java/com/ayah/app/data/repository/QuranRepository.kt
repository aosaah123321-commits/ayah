package com.ayah.app.data.repository

import com.ayah.app.data.local.ArabicTextNormalizer
import com.ayah.app.data.local.dao.AdhkarDao
import com.ayah.app.data.local.dao.AyahDao
import com.ayah.app.data.local.dao.AyahHistoryRecord
import com.ayah.app.data.local.entity.AdhkarEntity
import com.ayah.app.data.local.entity.AyahEntity
import com.ayah.app.data.local.entity.AyahHistoryEntity
import com.ayah.app.data.local.entity.FavoriteAyahEntity
import com.ayah.app.data.local.entity.SurahEntity
import com.ayah.app.data.preferences.AyahPreferencesRepository
import com.ayah.app.data.preferences.AyahSettings
import com.ayah.app.data.preferences.DisplayMode
import com.ayah.app.data.preferences.TriggerMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.Calendar

class QuranRepository(
    private val ayahDao: AyahDao,
    private val adhkarDao: AdhkarDao,
    private val preferences: AyahPreferencesRepository
) {
    val settingsFlow: Flow<AyahSettings> = preferences.settingsFlow
    val allSurahsFlow: Flow<List<SurahEntity>> = ayahDao.observeAllSurahs()
    val favoritesFlow: Flow<List<AyahEntity>> = ayahDao.observeFavorites()
    val historyFlow: Flow<List<AyahHistoryRecord>> = ayahDao.observeHistory()
    val shownCycleCountFlow: Flow<Int> = ayahDao.observeShownCycleCount()
    val totalAyahCountFlow: Flow<Int> = ayahDao.observeTotalAyahCount()

    fun observeSurahAyahs(surahNumber: Int): Flow<List<AyahEntity>> =
        ayahDao.observeAyahsBySurah(surahNumber)

    fun observeAdhkar(category: String): Flow<List<AdhkarEntity>> =
        adhkarDao.observeByCategory(category)

    fun observeIsFavorite(ayahId: Int): Flow<Boolean> =
        ayahDao.observeIsFavorite(ayahId)

    suspend fun toggleFavorite(ayahId: Int) {
        if (ayahDao.isFavorite(ayahId)) {
            ayahDao.removeFavorite(ayahId)
        } else {
            ayahDao.addFavorite(FavoriteAyahEntity(ayahId = ayahId, savedAtMs = System.currentTimeMillis()))
        }
    }

    suspend fun getAyahOrFallback(ayahId: Int): AyahEntity? =
        ayahDao.getAyahById(ayahId) ?: ayahDao.getFirstAyah()

    suspend fun getPassageForSettings(primaryAyah: AyahEntity, displayMode: DisplayMode): List<AyahEntity> {
        return if (displayMode == DisplayMode.SHORT_PASSAGE) {
            ayahDao.getPassageFromAyah(primaryAyah.surahNumber, primaryAyah.ayahNumber)
                .ifEmpty { listOf(primaryAyah) }
        } else {
            listOf(primaryAyah)
        }
    }

    suspend fun pickAndRecordNextAyah(triggerSource: String): List<AyahEntity> {
        val settings = preferences.settingsFlow.first()
        var chosen: AyahEntity? = if (settings.noRepeatEnabled) {
            ayahDao.getRandomUnshownAyah() ?: run {
                ayahDao.resetNoRepeatCycle()
                ayahDao.getRandomUnshownAyah()
            }
        } else {
            ayahDao.getRandomAyah()
        }

        if (chosen == null) {
            chosen = ayahDao.getFirstAyah() ?: return emptyList()
        }

        val passage = getPassageForSettings(chosen, settings.displayMode)
        val now = System.currentTimeMillis()
        ayahDao.markAyahsShownInCycle(passage.map { it.id })
        ayahDao.insertHistory(
            AyahHistoryEntity(
                ayahId = chosen.id,
                shownAtMs = now,
                triggerSource = triggerSource
            )
        )
        preferences.updateActiveAyah(chosen.id, now)
        return passage
    }

    suspend fun stepSequentialAyah(currentAyahId: Int, forward: Boolean): List<AyahEntity> {
        val settings = preferences.settingsFlow.first()
        val next = if (forward) {
            ayahDao.getNextSequentialAyah(currentAyahId) ?: ayahDao.getFirstAyah()
        } else {
            ayahDao.getPreviousSequentialAyah(currentAyahId) ?: ayahDao.getLastAyah()
        } ?: return emptyList()

        val now = System.currentTimeMillis()
        preferences.updateActiveAyah(next.id, now)
        return getPassageForSettings(next, settings.displayMode)
    }

    suspend fun searchOffline(rawQuery: String): List<AyahEntity> {
        val normalized = ArabicTextNormalizer.normalize(rawQuery)
        if (normalized.isBlank()) return emptyList()
        val ftsQuery = ArabicTextNormalizer.buildFtsQuery(rawQuery)
        val ftsResults = runCatching { ayahDao.searchAyahsFts(ftsQuery) }.getOrDefault(emptyList())
        return ftsResults.ifEmpty { ayahDao.searchAyahsLike(normalized) }
    }

    suspend fun resetNoRepeatCycle() = ayahDao.resetNoRepeatCycle()
    suspend fun clearHistory() = ayahDao.clearHistory()

    suspend fun shouldTriggerForEvent(event: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        val settings = preferences.settingsFlow.first()
        if (!settings.isLockScreenEnabled) return false
        if (isWithinQuietHours(settings)) return false

        return when (settings.triggerMode) {
            TriggerMode.EVERY_WAKE -> event == android.content.Intent.ACTION_SCREEN_ON
            TriggerMode.EVERY_UNLOCK -> event == android.content.Intent.ACTION_USER_PRESENT
            TriggerMode.INTERVAL -> {
                if (event != android.content.Intent.ACTION_SCREEN_ON) return false
                val intervalMs = settings.intervalMinutes.coerceAtLeast(1) * 60_000L
                (nowMs - settings.lastShownTimestampMs) >= intervalMs
            }
        }
    }

    fun isWithinQuietHours(settings: AyahSettings, calendar: Calendar = Calendar.getInstance()): Boolean {
        if (!settings.quietHoursEnabled) return false
        val start = settings.quietStartMinutes
        val end = settings.quietEndMinutes
        if (start == end) return false
        val nowMinutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        return if (start < end) {
            nowMinutes in start until end
        } else {
            nowMinutes >= start || nowMinutes < end
        }
    }
}
