# تطبيق آية (Ayah) — أندرويد (Kotlin & Jetpack Compose)

> **افتح هاتفك... وافتح قلبك بآية**
>
> **تطوير:** وايل الوايلي — دعواتكم جزاكم الله خيراً

## المزايا الرئيسية
- **١٠٠٪ دون إنترنت:** لا يطلب إذن `INTERNET` نهائياً.
- **عرض الآيات على شاشة القفل (`LockScreenAyahActivity`):** عبر خدمة أمامية خفيفة `ScreenMonitorService` ومستقبل `ACTION_SCREEN_ON` / `ACTION_USER_PRESENT`.
- **تذكير بالصلاة على النبي محمد وآله** مدمج في شاشة القفل والصفحة الرئيسية.
- **قاعدة بيانات محلية (Room + FTS4):** تحتوي فهرس السور الكامل (١١٤ سورة / ٦,٢٣٦ آية) مع التفسير الميسر وبحث فوري بدون تشكيل.
- **دعم منع التكرار (No-Repeat Cycle)** وأوقات عدم الإزعاج والوضع الليلي الكامل `AMOLED (#000000)`.

## لماذا لا يوجد ملف APK جاهز داخل ملف الـ ZIP؟ وكيف تستخرجه؟
تحتوي هذه الحزمة على **الكود المصدري الكامل** لتطبيق أندرويد (Kotlin + Jetpack Compose + Gradle)، ولا تتضمن ملف `.apk` مُجمَّعاً مسبقاً لأن بيئة العرض السحابية (الويب) لا تضم مترجم Android SDK وJDK. يمكنك استخراج ملف `app-debug.apk` قابل للتثبيت والإرسال لأي جهاز عبر إحدى الطرق التالية:

### الطريقة ١: تلقائياً عبر GitHub Actions (دون تثبيت Android Studio)
1. أنشئ مستودعاً جديداً على GitHub وارفع إليه محتويات هذا المجلد (مع التأكد من وجود `.github/workflows/build-apk.yml`).
2. افتح تبويب **Actions** ثم شغّل Workflow باسم **Build Ayah Android APK**.
3. بعد اكتمال البناء (حوالي دقيقتين)، حمّل الملف الجاهز **Ayah-Installable-APK** وشاركه أو ثبّته مباشرة على هاتفك.

### الطريقة ٢: عبر Android Studio (مباشرة)
1. افتح مجلد المشروع في **Android Studio Ladybug** أو أحدث.
2. انتظر انتهاء مزامنة Gradle.
3. من القائمة العلوية اختر: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. سيظهر الملف جاهزاً في: `app/build/outputs/apk/debug/app-debug.apk` — يمكنك إرساله وتثبيته مباشرة على أي هاتف أندرويد.

### الطريقة ٣: عبر سطر الأوامر (مع JDK 17 وAndroid SDK وGradle 8.9+)
```bash
bash scripts/build-apk.sh
```
أو عبر Gradle مباشرة:
```bash
gradle assembleDebug --no-daemon
```

## تعبئة النص الكامل للـ ٦,٢٣٦ آية
لتعبئة جميع الآيات الـ ٦,٢٣٦ من ملف مصحف المدينة (KFGQPC / Tanzil) والتفسير الميسر في `app/src/main/assets/quran_uthmani_muyassar.json`:
```bash
python3 scripts/prepare_quran_db.py --quran quran-uthmani.json --tafsir ar.muyassar.json
```
